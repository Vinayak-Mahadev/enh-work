package com.enhancesys.integration.services.dataengine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataEngineApplicationTests {

	@Test
	void contextLoads() {
	}

}
