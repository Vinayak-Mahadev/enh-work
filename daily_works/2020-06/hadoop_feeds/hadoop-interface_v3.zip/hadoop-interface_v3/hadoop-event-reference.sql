301 - MPC_CODE|MOBO_DATE|AMOUNT (INTHDP002-1166)
-- (1)
-- Source	: null, null
-- Instance	: null, null
-- Actor	: MPC_CODE, 10
-- Metric	: 21, 110

302 - MPC_CODE|DATE|ORGANIZATION_ID|DEALER_MSISDN|AMOUNT (INTHDP003-1167)
-- (1)
-- Source	: MPC_CODE
-- Instance	: null, null
-- Actor	: ORGANIZATION_ID, 10
-- Metric	: 21, 110	

303 - DATE|MICRO|SITE_ID|ID_OUTLET|QTY|AMOUNT (INTHDP004-1168)
-- (1)
-- Source	: SITE_ID, 12
-- Instance	: null, null
-- Actor	: ID_OUTLET, 10
-- Metric	: 21, 110	

-- (2)
-- Source	: SITE_ID, 12
-- Instance	: null, null
-- Actor	: MICRO, 13
-- Metric	: 21, 110	

304 - DATE|MICRO|SITE_ID|ID_OUTLET|STATUS_INJECTION|FLAG_ACM|COUNT_MSISDN (INTHDP005-1169)
-- (1)
-- Source	: SITE_ID, 12
-- Instance	: null, null
-- Actor	: ID_OUTLET, 10
-- Metric   : FLAG_ACM, 24

-- (2)
-- Source	: SITE_ID, 12
-- Instance	: null, null
-- Actor	: MICRO, 13
-- Metric   : FLAG_ACM, 24

305 - DATE|MICRO|SITE_ID|OUTLET|AMOUNT (INTHDP006-1170)
-- (1)
-- Source	: SITE_ID, 12
-- Instance	: null, null
-- Actor	: OUTLET, 10
-- Metric   : 21, 110

-- (2)
-- Source	: SITE_ID, 12
-- Instance	: null, null
-- Actor	: MICRO, 13
-- Metric   : 21, 110

306 - MOBO_DATE|ORG_CODE|AMOUNT (INTHDP007-1171)
-- (1)
-- Source	: null, null
-- Instance	: null, null
-- Actor	: ORG_CODE, 10
-- Metric   : 21, 110

307 - DATE|MICRO|SITE_ID|REVENUE_TYPE|REVENUE_TOTAL (INTHDP008-1172)
-- (1)
-- Source	: SITE_ID, 12
-- Instance : null, null
-- Actor	: MICRO, 13
-- Metric	: REVENUE_TYPE, 25	

308 - DATE|MICRO|SITE_ID|REVENUE (INTHDP009-1173)
-- (1)
-- Source	: SITE_ID, 12
-- Instance : null, null
-- Actor	: MICRO, 13
-- Metric	: 21, 110

309 - DATE|MICRO|SITE_ID|REVENUE (INTHDP010-1174)
-- (1)
-- Source	: SITE_ID, 12
-- Instance : null, null
-- Actor	: MICRO, 13
-- Metric	: 21, 110

310 - DATE|MICRO|SITE_ID|CATEGORY|TARGET|REVENUE (INTHDP011-1175)
-- (1)
-- Source	: SITE_ID, 12
-- Instance : null, null
-- Actor	: MICRO, 13
-- Metric	: CATEGORY, 23

311 - DATE|MICRO|SITE|QTY (INTHDP012-1176)
-- (1)
-- Source	: SITE, 12
-- Instance : null, null
-- Actor	: MICRO, 13
-- Metric	: 21, 110

312 - DATE|CLUSTER_ID|CATEGORY|CLUSTER_TYPE|TOTAL_RELOAD|CROSS_RELOAD (INTHDP013-1177)
-- (1)
-- Source	: null, null
-- Instance : CLUSTER_TYPE, 22
-- Actor	: CLUSTER_ID, 13
-- Metric	: CATEGORY, 23	

313 - DATE|CLUSTER_ID|TOTAL_DATA|CROSS_DATA (INTHDP014-1178)
-- (1)
-- Source	: null, null
-- Instance	: null, null
-- Actor	: CLUSTER_ID, 13
-- Metric	: 21, 110

314 - MONTH_ID|CLUSTER|ID_OUTLET|TARGET|ACTUAL (INTHDP015-1179)
-- (1)
-- Source	: CLUSTER, 13
-- Instance : null, null	
-- Actor	: ID_OUTLET, 10
-- Metric 	: 21, 110

315 - MONTH_ID|CLUSTER|MPC_CODE|PAYMENT_ALLOCATION (INTHDP016-1180)
-- (1)
-- Source	: CLUSTER, 13
-- Instance : null, null
-- Actor	: MPC_CODE, 10
-- Metric 	: 21, 110

316 - DATE|MICRO|SITE_ID|OUTLET|HIT|AMOUNT (INTHDP017-1181)
-- (1)
-- Source	: SITE_ID, 12
-- Instance : null, null
-- Actor	: OUTLET, 10
-- Metric   : 21, 110

-- (2)
-- Source	: SITE_ID, 12
-- Instance : null, null
-- Actor	: MICRO, 13
-- Metric   : 21, 110




